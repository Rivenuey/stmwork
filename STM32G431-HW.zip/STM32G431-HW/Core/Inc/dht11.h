#ifndef __DHT11_H
#define __DHT11_H

#include "main.h"

void PC2_input(void);
uint8_t dht11_init(void);
uint8_t  dht11_read_data(uint8_t *temp,uint8_t *humi);
uint8_t dht11_read_byte(void);
uint8_t dht11_reat_bit(void);
uint8_t dht11_check(void);
void dht11_res(void);
void delay_ms(uint32_t ms);
void delay_us(uint32_t nus);

void PC2_input(void);
void PC2_output(void);


#endif