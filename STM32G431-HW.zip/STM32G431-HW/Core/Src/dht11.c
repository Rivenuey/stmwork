#include "dht11.h"
#include "main.h"

//��ʱ����
void delay_us(uint32_t nus)				//��ʱ����us��
{
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000000);
HAL_Delay(nus-1);
HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);
}

void delay_ms(uint32_t ms)				//��ʱ����ms��
{
	HAL_Delay(ms);
}


//��λdht11
void dht11_res(void)
{
	PC2_output();	//�������
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,0);		//���͵ȴ�
	delay_ms(20);		//��ʱ�ȴ�18-40ms
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,1);		//���ߵȴ�
	delay_us(30);
}

//�ȴ�dht11��Ӧ
uint8_t dht11_check(void)
{
	uint8_t retry = 0;
	PC2_input();
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13) == 1 && retry < 100)
	{
		delay_us(1);
		retry++;
	}
	if(retry >= 100) return 1;
	else retry = 0 ;
	
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13) == 0 && retry < 100)
	{
		delay_us(1);
		retry++;
	}
	if(retry >= 100) return 1;
	return 0 ;
}

//��ȡdht11һλ
uint8_t dht11_reat_bit(void)
{
	uint8_t retry = 0;
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13) == 1 && retry < 100)	//��ȡ�ߵ�ƽ
	{
		delay_us(1);
		retry++;
	}
	retry = 0;
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13) == 0 && retry < 100)	//��ȡ�͵�ƽ
	{
		delay_us(1);
		retry++;
	}
	delay_us(40);
	if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13) == 1) 	return 1;
	else return 0;
}

//��ȡһ���ֽ�
uint8_t dht11_read_byte(void)
{
	uint8_t i,data;
	data = 0;
	for(i = 0 ;i<8;i++)
	{
		data<<=1;
		data|=dht11_reat_bit();
	}
	return data;
}

//��ȡһ������
uint8_t  dht11_read_data(uint8_t *temp,uint8_t *humi)
{
	uint8_t buf[5];
	uint8_t i;
	dht11_res();
	if(dht11_check() == 0)		//��Ӧ�ɹ�
	{
		for(i = 0;i<5;i++)
		{
			buf[i] = dht11_read_byte();
		}
		if((buf[0]+buf[1]+buf[2]+buf[3]) == buf[4])
		{
			*humi = buf[0];
			*temp = buf[2];
			
		}else return 1;
	}else return 1;
	return 0;
}
uint8_t dht11_init(void)
{
    GPIO_InitTypeDef GPIO_Initure;
    __HAL_RCC_GPIOC_CLK_ENABLE();			      //����GPIOCʱ��
	
    GPIO_Initure.Pin=GPIO_PIN_13;            //PB12
    GPIO_Initure.Mode=GPIO_MODE_OUTPUT_PP;  //�������
    GPIO_Initure.Pull=GPIO_PULLUP;          //����
    GPIO_Initure.Speed=GPIO_SPEED_HIGH;     //����
    HAL_GPIO_Init(GPIOC,&GPIO_Initure);     //��ʼ��
 
    dht11_res();
	 return dht11_check();
}
//����PC2״̬
void PC2_input(void)		//��������
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC2 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

void PC2_output(void)	//�������
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC2 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}